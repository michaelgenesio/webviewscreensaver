//
//  main.m
//  WebViewScreenSaverRig
//
//  Created by Alastair Tse on 26/04/2015.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
  return NSApplicationMain(argc, argv);
}
